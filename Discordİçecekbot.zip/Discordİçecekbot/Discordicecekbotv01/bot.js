const Discord = require('discord.js');
const client = new Discord.Client();
;

client.on('ready', () => {
  console.log(`BOT: ${client.user.username} adı ile giriş yaptı!`);
});

client.on('message', message => {
    if (message.content === '!suiç') {
    	message.reply('https://cdn.discordapp.com/attachments/444421656874844160/466022020178771976/su.jpeg Afiyet Olsun🌷');
  	}
});

client.on('message', message => {
    if (message.content === '!limonataiç') {
    	message.reply('https://cdn.discordapp.com/attachments/459010687897960448/466146249519792138/limonata.jpeg Afiyet Olsun🌷');
  	}
});

client.on('message', message => {
    if (message.content === '!yapımcı') {
    	message.reply('Botun Kodlayacısı Ve Yapımcısı ByGold.');
  	}
});
      
client.on('message', message => {
    if (message.content === 'Selamun Aleykum') {
    	message.reply('Aleykum Selam Hoşgeldin🌷');
  	}
});

client.on('message', message => {
    if (message.content === 'sa') {
    	message.reply('Aleykum Selam Hoşgeldin🌷');
  	}
});

client.on('message', message => {
    if (message.content === '!kahveiç') {
    	message.reply('https://cdn.discordapp.com/attachments/444421656874844160/466022020656791562/kahve.jpeg Afiyet Olsun🌷');
  	}
});

client.on('message', message => {
    if (message.content === '!destek') {
    	message.reply('Herhangi Bir Sorununuz Varsa ByGold#3095 Mesaj Atın.');
  	}
});

client.on('message', message => {
    if (message.content === '!çayiç') {
    	message.reply('https://cdn.discordapp.com/attachments/444421656874844160/466023250040848404/cay.jpeg  Afiyet Olsun🌷');
  	}
});

client.on('message', message => {
    if (message.content === '!colaiç') {
    	message.reply('https://cdn.discordapp.com/attachments/459010687897960448/466150544658923520/cola.jpeg  Afiyet Olsun🌷');
  	}
});

client.on('message', message => {
    if (message.content === '!beniseviyormusun') {
        message.reply('evet🌷');
  	}
});
  
client.on('message', message => {
    if (message.content === '!komutlar') {
    	message.reply('!suiç,!kahveiç,!çayiç,!limonataiç,!beniseviyormusun,!destek,!türkkahveiç');
  	}
});

client.on('message', message => {
    if (message.content === '!türkkahvesiç') {
    	message.reply('https://cdn.discordapp.com/attachments/459010687897960448/466151755516739585/turkkahvesi.jpeg Afiyet Olsun🌷');
  	}
});
 
// THIS  MUST  BE  THIS  WAY
client.login(process.env.BOT_TOKEN)
